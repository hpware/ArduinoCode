#include "../values.h"
#include <Arduino.h>

void buttoninit() {
    pinMode(b1p, INPUT);
    pinMode(b2p, INPUT);
    pinMode(b3p, INPUT);
}