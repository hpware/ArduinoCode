// State of those buttons.
int b1s = 0;
int b2s = 0;
int b3s = 0;
//Button Pins?
int b1p = 33;
int b2p = 34;
int b3p = 36;
// Screen SDA SCL pins
int sda = 21;
int scl = 22;